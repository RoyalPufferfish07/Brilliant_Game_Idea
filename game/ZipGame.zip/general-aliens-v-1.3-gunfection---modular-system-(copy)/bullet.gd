extends CharacterBody2D
const SPEED = 1000
const RANGE = 1200
#@export var speed = 750
var travelled_distance = 0
func _physics_process(delta):

	#position += transform.x * speed * delta
	var direction = Vector2.RIGHT.rotated(rotation)
	position += direction * SPEED * delta
	travelled_distance += SPEED * delta
	if travelled_distance > RANGE:
		queue_free()
	move_and_slide()


#func _on_area_2d_body_entered(body: Node2D) -> void:
	#if body.is_in_group("Enemy"):
		#body.dmg()
		#queue_free() # Replace with function body.
