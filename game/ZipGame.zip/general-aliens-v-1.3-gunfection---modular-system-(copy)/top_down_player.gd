extends CharacterBody2D
#Character Movement
var input: Vector2 = Vector2.ZERO # this was giving me error for being null when it was not defined as Vectro2.ZERO
@export var speed = 400.0
@export var acel = 2.0  # speed in pixels/sec
@export var friction = 2.0
@onready var sprite: AnimatedSprite2D = $Sprite
@onready var stop_particle: CPUParticles2D = $StopParticle
#Gun Mechanic
@onready var weapon_pivot: Marker2D = $WeaponPivot
@onready var shooting_point: Marker2D = $WeaponPivot/Gun/ShootingPoint
var can_shoot = true
@onready var gun_cooldown: Timer = $GunCooldown
@onready var gun: Sprite2D = $WeaponPivot/Gun
#Gun Selection
const E_gun = preload("uid://dfx8sp61elgfh")
const L_gun = preload("uid://brptpc8jk0ry")
const S_gun = preload("uid://c7tvc5q85wdx4")
var gun_array = [S_gun,E_gun,L_gun]#simple gun(ak47), Explsovie gun(bazooka), Laser gun
var cur_gun_index = 0
#Bullet Selection
const BULLET = preload("uid://cqruyfumolw5l")
const EXPLOSIVE = preload("uid://bipbqtlyq3yrk")
const LASER = preload("uid://djt3drs5e8p66")
var bullet_array = [BULLET, EXPLOSIVE, LASER]
#func _ready() -> void:
	#print(gun_array.get(0))
	#print(gun_array.size())
func _physics_process(delta):
	#print(cur_gun_index)
	if cur_gun_index > gun_array.size() -1:
		cur_gun_index = 0
	if cur_gun_index < 0:
		cur_gun_index = gun_array.size() -1
	if Input.is_action_just_pressed("Scroll Up"):
		cur_gun_index += 1
	if Input.is_action_just_pressed("Scroll Down"):
		cur_gun_index -= 1
	gun.set_texture(gun_array.get(cur_gun_index))
	weapon_pivot.look_at(get_global_mouse_position())
	
	var player_input = get_input()
	
	if player_input.x >0: 
		sprite.flip_h = false
		stop_particle.position.x = 29.0
		stop_particle.scale.x = 1.0
	elif player_input.x <0: 
		sprite.flip_h = true
		stop_particle.position.x = -29.0
		stop_particle.scale.x = -1.0
	if player_input:
		if sprite.animation != "Walk" : sprite.play("Walk")
		sprite.speed_scale = (velocity/speed).distance_to(Vector2.ZERO)+0.5
	if !player_input and velocity.distance_to(Vector2.ZERO) < 200 and velocity.distance_to(Vector2.ZERO) > 100 :
		stop_particle.emitting = true
		if sprite.animation != "Brake" : sprite.play("Brake")
		sprite.speed_scale = (velocity/speed).distance_to(Vector2.ZERO)+0.5
	if !player_input and velocity.distance_to(Vector2.ZERO) < 100:
		if sprite.animation != "Idle" : sprite.play("Idle")
		sprite.speed_scale = 0.75
#figure out how to do a stop animation instead of just imedtiallty going to idleada
	if player_input:
		#print("PLAYER")
		velocity = lerp(velocity, player_input * speed, delta * acel)
	if !player_input:
		#print("NULL")
		velocity = lerp(velocity, player_input * speed, delta * friction)
	move_and_slide()
	if Input.is_action_just_pressed("Shoot") or can_shoot and Input.is_action_pressed("Shoot"):
		shoot()
		can_shoot = false
		gun_cooldown.start()

func get_input():
	input.x = Input.get_action_strength("Right") - Input.get_action_strength("Left")
	input.y = Input.get_action_strength("Down") - Input.get_action_strength("Up")
	return input.normalized()
func shoot():
	var bullet_insta = bullet_array.get(cur_gun_index).instantiate()
	get_tree().root.add_child(bullet_insta) # this fixed it
	#bullet_insta.rotation = weapon_pivot.rotation
	bullet_insta.global_position = shooting_point.global_position 
	bullet_insta.global_rotation = shooting_point.global_rotation 
	#shooting_point.add_child(bullet_insta) this was making it weird fixed it with the one above


func _on_gun_cooldown_timeout() -> void:
	can_shoot = true # Replace with function body.
#Modular Gun System
