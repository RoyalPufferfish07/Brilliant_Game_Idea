extends CharacterBody2D

@export var speed = 750

func _physics_process(delta):
	position += transform.x * speed * delta
	move_and_slide()


#func _on_area_2d_body_entered(body: Node2D) -> void:
	#if body.is_in_group("Enemy"):
		#body.dmg()
		#queue_free() # Replace with function body.
