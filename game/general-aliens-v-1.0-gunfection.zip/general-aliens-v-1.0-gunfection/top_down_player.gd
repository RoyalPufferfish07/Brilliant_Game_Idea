extends CharacterBody2D
var input: Vector2 = Vector2.ZERO # this was giving me error for being null when it was not defined as Vectro2.ZERO
@export var speed = 400.0
@export var acel = 2.0  # speed in pixels/sec
@export var friction = 2.0
@onready var sprite: AnimatedSprite2D = $Sprite
@onready var stop_particle: CPUParticles2D = $StopParticle
const BULLET = preload("uid://cqruyfumolw5l")
@onready var arm: Marker2D = $Arm
var can_shoot = true
@onready var gun_cooldown: Timer = $GunCooldown
@onready var ak_47: Sprite2D = $Arm/Ak47


func _physics_process(delta):
	arm.look_at(get_global_mouse_position())
	
	var player_input = get_input()
	
	if player_input.x >0: 
		sprite.flip_h = false
		stop_particle.position.x = 29.0
		stop_particle.scale.x = 1.0
	elif player_input.x <0: 
		sprite.flip_h = true
		stop_particle.position.x = -29.0
		stop_particle.scale.x = -1.0
	if player_input:
		if sprite.animation != "Walk" : sprite.play("Walk")
		sprite.speed_scale = (velocity/speed).distance_to(Vector2.ZERO)+0.5
	if !player_input and velocity.distance_to(Vector2.ZERO) < 200 and velocity.distance_to(Vector2.ZERO) > 100 :
		stop_particle.emitting = true
		if sprite.animation != "Brake" : sprite.play("Brake")
		sprite.speed_scale = (velocity/speed).distance_to(Vector2.ZERO)+0.5
	if !player_input and velocity.distance_to(Vector2.ZERO) < 100:
		if sprite.animation != "Idle" : sprite.play("Idle")
		sprite.speed_scale = 0.75
#figure out how to do a stop animation instead of just imedtiallty going to idleada
	if player_input:
		#print("PLAYER")
		velocity = lerp(velocity, player_input * speed, delta * acel)
	if !player_input:
		#print("NULL")
		velocity = lerp(velocity, player_input * speed, delta * friction)
	move_and_slide()
	if Input.is_action_just_pressed("Shoot") or can_shoot and Input.is_action_pressed("Shoot"):
		shoot()
		can_shoot = false
		gun_cooldown.start()

func get_input():
	input.x = Input.get_action_strength("Right") - Input.get_action_strength("Left")
	input.y = Input.get_action_strength("Down") - Input.get_action_strength("Up")
	return input.normalized()
func shoot():
	var bullet_insta = BULLET.instantiate()
	bullet_insta.rotation = arm.rotation
	bullet_insta.position = arm.position 
	add_child(bullet_insta)


func _on_gun_cooldown_timeout() -> void:
	can_shoot = true # Replace with function body.
